// Screen/app capture plus the sharer's quality settings.
(() => {
  SD.RESOLUTIONS = {
    source: { label: 'Source (full)', w: 0, h: 0 },
    '1440': { label: '1440p', w: 2560, h: 1440 },
    '1080': { label: '1080p', w: 1920, h: 1080 },
    '720': { label: '720p', w: 1280, h: 720 },
    '480': { label: '480p', w: 854, h: 480 },
  };
  SD.FRAME_RATES = [15, 30, 60];

  SD.shareSettings = (serverDefaultMode) => ({
    mode: serverDefaultMode || 'p2p',
    res: '1080',
    fps: 30,
    optimize: 'detail', // 'detail' (text, UI) | 'motion' (video, games)
    audio: true,
    ...SD.store.get('share', {}),
  });

  // Target size for a frame of w×h under a resolution cap (keeps aspect, even numbers).
  SD.capSize = (w, h, resKey) => {
    const cap = SD.RESOLUTIONS[resKey] || SD.RESOLUTIONS.source;
    let s = 1;
    if (cap.w && cap.h) {
      const portrait = h > w;
      const [cw, ch] = portrait ? [cap.h, cap.w] : [cap.w, cap.h];
      s = Math.min(1, cw / w, ch / h);
    }
    const even = (v) => Math.max(2, Math.round((v * s) / 2) * 2);
    return { w: even(w), h: even(h) };
  };

  // Video bitrate (bits/s) that looks good for this size, frame rate and content.
  SD.targetBitrate = (w, h, fps, optimize) => {
    const base = optimize === 'motion' ? 6_000_000 : 4_000_000; // 1080p30
    const v = base * ((w * h) / (1920 * 1080)) * Math.pow(fps / 30, 0.75);
    return Math.round(SD.clamp(v, 400_000, 25_000_000));
  };

  // Desktop app: system audio capture is available on Windows.
  SD.canSystemAudio = () => (SD.isDesktop ? !!window.desktop.info?.systemAudio : true);

  /**
   * Starts capturing. In the desktop app `sourceId` comes from our own picker;
   * in a browser the browser shows its own picker.
   */
  SD.startCapture = async (settings, sourceId) => {
    const fps = Number(settings.fps) || 30;
    const cap = SD.RESOLUTIONS[settings.res] || SD.RESOLUTIONS.source;
    const video = { frameRate: { ideal: fps, max: fps } };
    if (cap.w) { video.width = { max: cap.w }; video.height = { max: cap.h }; }
    const wantAudio = !!settings.audio && SD.canSystemAudio();

    let stream;
    if (SD.isDesktop) {
      await window.desktop.selectSource(sourceId, wantAudio);
      stream = await navigator.mediaDevices.getDisplayMedia({ video, audio: wantAudio });
    } else {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { ...video, cursor: 'always' },
        audio: wantAudio ? { suppressLocalAudioPlayback: false } : false,
        selfBrowserSurface: 'exclude',
        systemAudio: 'include',
        surfaceSwitching: 'include',
      });
    }
    const track = stream.getVideoTracks()[0];
    try { track.contentHint = settings.optimize === 'motion' ? 'motion' : 'detail'; } catch { /* unsupported */ }
    try { await track.applyConstraints(video); } catch { /* keep what we got */ }
    return stream;
  };

  SD.describeTrack = (stream) => {
    const t = stream.getVideoTracks()[0];
    const s = t?.getSettings?.() || {};
    let label = t?.label || 'Screen';
    if (/^(screen|window|web-contents-media-stream):/.test(label) || !label) label = 'Screen';
    return { width: s.width || 0, height: s.height || 0, label, surface: s.displaySurface || '' };
  };
})();
